package com.example.pr8;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;


import android.app.Fragment;
import android.os.Bundle;

public class pr8 extends Fragment  implements ToolbarFragment.ToolbarListener  {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }
    public void onButtonClick(int fontsize, String text) {

    }
}﻿
public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }
}
